package PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class StoreObjects {

	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")
	private WebElement signin;

	@FindBy(id = "email_create")
	private WebElement crtacct;

	@FindBy(css = "#SubmitCreate > span")
	private WebElement crtacctbtn;

	@FindBy(xpath = "//*[@id=\"email\"]")
	private WebElement eaddac;

	@FindBy(xpath = "//*[@id=\"passwd\"]")
	private WebElement eadpass;

	@FindBy(xpath = "//*[@id=\"SubmitLogin\"]/span")
	private WebElement valsignin;

	@FindBy(xpath = "//*[@id=\"header\"]/div[2]/div/div/nav/div[2]/a")
	private WebElement signoutbtn;

	@FindBy(xpath = "//*[@id=\"email\"]")
	private WebElement inemail;

	@FindBy(id = "email_create")
	private WebElement incrtacct;
	
	@FindBy(css = "#search_query_top")
	private WebElement srch;
	
	@FindBy(xpath = "//*[@id=\"searchbox\"]/button")
	private WebElement srchbtn;
	
	@FindBy(className = "icon-home")
	private WebElement homebtn;
	
	public void search(String search) {
		
		srch.clear();
		srch.sendKeys(search);
		srchbtn.click();
		homebtn.click();
	}

	public void signin() {

		signin.click();
	}

	public void signout() {

		signoutbtn.click();
	}

	public void createacc(String email) {

		crtacct.clear();
		crtacct.sendKeys(email);
	}

	public void invalidcrtacc(String invemail) {

		incrtacct.clear();
		incrtacct.sendKeys(invemail);
	}

	public void clickbtn() {

		crtacctbtn.click();
	}

	public void valemail(String acemail) {

		eaddac.sendKeys(acemail);
	}

	public void valpass(String eadpass1) {

		eadpass.sendKeys(eadpass1);
	}

	public void validsig() {

		valsignin.click();
	}

	public void invalid(String eminvalid) {

		inemail.clear();
		inemail.sendKeys(eminvalid);
	}

	public StoreObjects(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
