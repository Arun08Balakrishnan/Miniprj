package Main;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import PageObject.StoreObjects;

public class YourStoreTC {

	WebDriver driver;
	StoreObjects so;

	@BeforeMethod
	public void before() {
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		String Title = driver.getTitle();
		String Actual = "My Store";
		System.out.println("The Title is : " + Title);
		assertEquals(Title, Actual);
		so = new StoreObjects(driver);

	}
	
	@Test(priority =0)
	public void start1() {
		so.signin();
		so.invalidcrtacc("aravi");
		so.clickbtn();
	}

	@Test(priority =1)
	public void start2() {
		so.signin();
		so.createacc("aravi@gmail.com");
		so.clickbtn();
		so.signin();
	}

	@Test(priority =2)
	public void start3() {
		so.signin();
		so.invalid("aravind");
		so.validsig();
	}

	@Test(priority =3)
	public void start4() {
		so.signin();
		so.valemail("aravind@gmail.com");
		so.valpass("Hello@98");
		so.validsig();
		so.signout();
	}
	
	@Test(priority =4)
	public void start5() {
		so.search("shirts");
	}

}
